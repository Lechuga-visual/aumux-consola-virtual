# AuMux

**AuMux**, antes Monitor Mix, es una miniapp Windows x64 para mezclar entradas ASIO o probar generadores por la
salida normal del PC, crear mezclas auxiliares y enviar el master a OBS.
Repositorio: [Lechuga-visual/aumux-consola-virtual](https://github.com/Lechuga-visual/aumux-consola-virtual).

**Prioridad del proyecto:** mezcla y monitoreo en tiempo real con la menor
latencia estable de extremo a extremo, también hacia OBS y por red. La escucha
web permite objetivos de búfer de 40/80/120/200 ms (80 ms inicialmente), más el retardo de red y reproducción;
su optimización y medición son prioritarias en la
[hoja de ruta](docs/hoja-de-ruta.md).

**Prueba local:** [descargar Windows x64](https://github.com/Lechuga-visual/aumux-consola-virtual/releases/download/v0.13.3/AuMux-0.13.3-Windows-x64.zip)
e [instrucciones para Windows](docs/probar-en-windows.md).
La descarga incluye el ejecutable, el receptor de OBS y el código fuente.
Su checksum está en [SHA-256](dist/AuMux-0.13.3-Windows-x64.zip.sha256).

**Capturas:** [galería de la interfaz actual](docs/capturas.md), con consola,
efectos, preferencias y vistas remotas para tablet y celular.

## Novedades 0.13.3 · efectos en vivo

Puedes añadir, reemplazar, quitar y reordenar inserts nativos/VST3 sin detener
el motor. Se preparan fuera del hilo de audio y se reutilizan las instancias que
siguen en la cadena. DEMO también renderiza en un hilo independiente.
[Funcionamiento y tabla de cambios que requieren detener audio](docs/interfaz-0.13.3.md).

## Novedades 0.13.2 · navegador de plugins

**＋ FX** abre un menú rápido por categorías en cada canal, auxiliar y master.
La ventana de plugins incorpora el navegador completo de dos columnas, con búsqueda,
filtros de fabricante/formato, favoritos, recientes y clasificación manual.
[Uso y capturas de ambos selectores](docs/interfaz-0.13.2.md).

## Novedades 0.13.1 · paneles independientes

Herramientas, plugins, EQ, compresor, envíos y preferencias se abren en ventanas
independientes, sincronizadas con la consola y el mismo motor. Puedes elegir
paneles flotantes arrastrables dentro de la consola desde **Herramientas → Paneles**.
[Uso y comportamiento del navegador](docs/interfaz-0.13.1.md).

## Novedades 0.13 · pruebas de audio

**Herramientas → Latencia y diagnóstico** reúne datos en tiempo real, loopback
físico, barridos de buffers, comparación de rutas/EFX e informes HTML/JSON.
Detector/eliminador de acoples con cortes manuales en el EQ, detector de fase y
osciloscopio tienen entradas propias. Ver [guía y alcance de las mediciones](docs/interfaz-0.13.md).

## Novedades 0.12 · AuMux Audio

El receptor de OBS se llama **AuMux Audio** y conserva las escenas existentes.
Añade flujos UDP identificados para master y auxiliares, envío a varios destinos
o broadcast local, búfer por receptor y sincronización nativa de OBS. Incluye un
editor propio con estilo AuMux, medidores reales y diagnóstico.

Configura los envíos en **Preferencias → AuMux Audio · envíos UDP**.
Consulta [la guía 0.12](docs/interfaz-0.12.md) y [el puente hacia OBS](docs/puente-obs.md).
Windows incluye el editor nativo; el receptor y editor Qt6 se compilan y prueban
contra libobs en Linux. macOS y Flatpak requieren validación y empaquetado propios.

![Editor AuMux Audio probado en Linux con Qt6](docs/aumux-0.12-obs-editor-linux.png)

## Corrección 0.11.2

En modo touch, los faders de consola local y remota solo se mueven al arrastrar
la perilla. La mezcla de auxiliares usa el mismo gesto. Tocar el recorrido o
usarlo para desplazarse lateralmente mantiene los niveles.
Ver [faders touch](docs/interfaz-0.11.2.md).

## Corrección 0.11.1

El servidor HTTP restablece el modo de las conexiones aceptadas en Windows,
para que las cabeceras fragmentadas y las respuestas grandes de la consola
completa no fallen por `WouldBlock`. Ver [corrección de consola remota](docs/interfaz-0.11.1.md).

## Funciones actuales

- Marca AuMux y logo propio; ejecutable **AuMux.exe**.
- Preferencias por categoría, con **Redes y servidores** al principio; consola remota, auxiliares y escucha tienen páginas propias.
- Control de auxiliares por **WebSocket**: cambios agrupados cada 80 ms, estado cada 100 ms y confirmación después de aplicar. Reconecta consultando el estado real y descarta cambios pendientes antiguos.
- CPU y RAM del proceso y latencia declarada por el driver —o duración de bloque si no está disponible— en el pie de consola.
- Bandeja de Windows sin terminal: abrir consola, IP local, latencia, CPU, RAM y cerrar servicio con confirmación. Detección de segunda instancia normal.
- Lectura HTTP por bloques, reconexión de escucha y selección del objetivo de búfer de red.
- Preparación de firma Authenticode y [opciones gratuitas para código abierto](docs/firma-windows.md).

- Modo touch de activación manual en Herramientas; faders sin scroll vertical y vistas móvil/tablet/escritorio.
- Enlace único de mezcla con contraseña compartida o abierto, con selector de auxiliar; se conservan enlaces personales.
- Consola principal remota independiente, con contraseña opcional y opción de deshabilitarla.
- Escucha con clave, contraseña o enlace abierto; selector de direcciones locales/Tailscale por tarjeta.
- Diagnóstico de latencia por componentes y calculadora a 48 kHz, sin confundir RTT con audio extremo a extremo.

- **Control remoto web por auxiliar:** enlaces personales revocables, faders, mute por envío y PRE/POST con permisos.
- Dirección IP Tailscale o MagicDNS para compartir control y escucha; puertos separados.

- Compresor nativo por canal, aux y master: curva, perillas, reducción de ganancia real y sidechain externo.
- Superficie centrada con pocos canales; desplazamiento horizontal y tiras fijables a izquierda/derecha.
- Menú contextual propio sobre las tiras y selección de texto reservada a campos editables.
- **Escucha LAN** en otro puerto: cada navegador elige main o un aux; hasta ocho oyentes de referencia.

- De 1 a 64 canales y de 0 a 32 auxiliares: botones **+ Canal / + Aux** sobre sus bancos y panel **Canales y auxiliares**, también con audio activo.
- Canales y auxiliares mono/estéreo conmutables en vivo; los nuevos aux son mono.
- Entradas físicas L/R independientes del número de tiras. Trabajo a 48 kHz.
- Faders compactos con marcas alineadas y entrada numérica exacta; envíos pre/post, panorama y mute.
- Salidas físicas mono o pares estéreo independientes y stream dúplex RtAudio/ASIO.
- EQ paramétrico nativo por canal, auxiliar y master: ocho bandas FreeEQ8, seis tipos, fase mínima.
- EQ con curva interactiva, ocho puntos de color y perillas de frecuencia, ganancia y Q.
- Cadena FX con lista lateral, selección, agregar, quitar con Supr y reordenar; cuatro inserts por tira.
- FreeVox8 y MDA con perillas; VST3 con editor genérico de deslizadores y valores.
- Parámetros nativos y bypass editables en vivo; presets de usuario persistentes, importación/exportación JSON.
- Ventana **Envíos ↗** por canal: master, pan y envíos PRE/POST con controles gráficos.
- FreeVox8 (vocoder filterbank) y los 20 efectos de audio MDA integrados.
- Lista de VST3 instalados en carpetas estándar de Windows, con búsqueda y carpeta adicional.
- Consola compacta basada en las referencias Fairlight: módulos alineados, faders largos y colores por tipo.
- Fader Flip Main/Aux dinámico, botón MAIN y doble clic en pan para centrar, vista completa/reducida y paneles de medidores/inspector ocultables.
- Control Room para escucha PC de un bus, con medidor estéreo propio.
- Ruido blanco, rosa y seno independientes por canal, antes de los inserts.
- AUDIO PC por WASAPI: escucha master o monitores sin controlador ASIO ni interfaz externa.
- Modo DEMO sin dispositivo, medidores, silencio total reversible y ajustes JSON.
- Puente de master por UDP local y receptor para OBS x64 32.1 o posterior.
- Instalador OBS corregido a ProgramData, diagnóstico y confirmación de recepción.

La miniapp reutiliza **los crates DSP y VST3 de SoundCraft de Artcraft**,
fijados a una revisión concreta. La interfaz y el ruteo son propios; no es
un fork de todo el DAW. No requiere controlar un mezclador externo ni instalar REAPER.

![Consola AuMux 0.12.0 con ocho canales, cuatro auxiliares y master](docs/screenshots/0.12.0/01-consola.png)

Para probar sin hardware: **AUDIO PC → G en un canal → Control Room → Input**.
DEMO procesa sin reproducir. Las escenas 0.1 siguen siendo compatibles.

## Ejecutar y compilar

El ZIP Windows incluye **AuMux.exe**, el receptor OBS, guía y fuente. No
necesita compilador para probarlo. Arranca detenido, sin salidas asignadas.

Código de la app: `desktop/`. Para compilar localmente en Windows con Rust
1.95 y Visual Studio C++ Build Tools, ejecuta `desktop/build-windows.ps1`.
El Cargo.lock se conserva; usar siempre `--locked`.

En esta máquina Linux, `bash tools/setup-cloud.sh` prepara las dependencias
en `/workspace` y verifica el motor y la compilación cruzada. La UI se inicia
con `desktop/target/debug/aumux --no-browser` y la consola imprime su
dirección local. El modo DEMO no abre hardware. Cierra el proceso al acabar.

`bash tools/validate-desktop.sh` ejecuta las pruebas de audio, red y Chromium.
La preparación instala el cliente Python de pruebas WebSocket fijado en
`desktop/tests/requirements.txt` dentro de `/workspace/.aumux-test-deps`, mediante
HTTPS y sin modificar los paquetes globales. La app distribuida no requiere
Python. Con la app compilada, la prueba de red se puede repetir con:

```sh
PYTHONPATH=/workspace/.aumux-test-deps python3 desktop/tests/websocket-smoke.py
```

## Validación y límites

Se verificaron ruteo y mute, procesamiento con un binario VST3 de prueba,
la UI en Chromium y audio real desde DEMO hasta callbacks de libobs en Linux.
Los binarios de Windows se compilaron y se inspeccionaron sus dependencias;
**no se ejecutaron nativamente en Windows ni se probaron con hardware ASIO**.

El cambio de estructura se prepara fuera del callback de audio y se adopta al
terminar un bloque. Conserva los inserts existentes y devuelve la memoria al
hilo de control; no reabre el dispositivo. Las salidas ASIO disponibles se
abren al inicio. Cambiar dispositivo, entradas físicas abiertas o buffer exige
detener el motor. Agregar, reemplazar, quitar y reordenar inserts funciona en
vivo; editar parámetros de un VST3 ya activo desde su editor aún exige detenerlo.
Parámetros nativos, EQ, bypass, niveles, envíos, formatos y cantidad de tiras
funcionan en vivo. Los presets de usuario se guardan en
`%LOCALAPPDATA%\MonitorMix\presets.json` en Windows. Se conserva esa carpeta
interna para seguir encontrando las bibliotecas de versiones anteriores.

Es un prototipo: no hay compensación de latencia, editor nativo VST3 ni
estado binario de presets; se admiten cuatro inserts por tira. Faltan las pruebas
de ASIO real, compatibilidad de efectos, sincronía con video y sesiones largas.
La guía detalla estas limitaciones y la prueba paso a paso.

El receptor conserva su DLL, ID y nombre de fuente **Monitor Mix — master local**
para mantener las escenas OBS existentes. En 0.3 se corrigió su ruta: ejecuta el nuevo instalador como
administrador con OBS cerrado. OBS 32.2.2 x64 es compatible. Consulta
[el puente AuMux Audio, su configuración y latencia](docs/puente-obs.md).

## Control remoto previsto

[Dirección OSC, Mackie Control y Mackie HUI](docs/control-remoto.md): se prevé
un modo controlador sin abrir audio, además del mezclador independiente.
Estos protocolos y los perfiles de dispositivos quedan para la siguiente etapa;
no se implementan en 0.11.

## Componentes anteriores

`include/`, `src/` y las pruebas CMake son el primer motor C++ portable.
Se conservan, pero no son el motor de la miniapp Rust actual. La
[utilidad OSC experimental](docs/osc.md) tampoco es necesaria para usar AuMux.

Licencias y procedencia: [desktop/THIRD_PARTY.md](desktop/THIRD_PARTY.md).

La integración nativa usa el núcleo de fase mínima de FreeEQ8 y el motor
filterbank de FreeVox8; no incorpora todas las funciones de esos plugins.
MDA incluye sus 20 efectos de audio. Los instrumentos virtuales quedan fuera
del alcance. La grabación multipista y OSC/Mackie quedan pendientes.
La aplicación combinada desde 0.5 se distribuye bajo GPL-3.0-only, con fuentes,
licencias y procedencia en el ZIP.

[Touch, accesos unificados, consola remota y latencia 0.9](docs/interfaz-0.9.md).

[Hoja de ruta](docs/hoja-de-ruta.md): otros dispositivos y subsistemas Windows,
optimización de escucha de baja latencia, grabación multipista y control OSC/Mackie.

[AuMux, auxiliares WebSocket, preferencias y bandeja 0.11](docs/interfaz-0.11.md).
